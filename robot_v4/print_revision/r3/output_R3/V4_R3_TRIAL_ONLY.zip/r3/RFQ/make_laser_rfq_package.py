"""Package the R3 laser-cut metal parts for shop quotes (quote request only, not a production order).

Copies DXF/STEP from output_R3/DRAFT/metal unchanged (SHA-checked), adds mirror-derived reference STEPs for the
right wedgelet and left skirt (checked against build_report.json), renders previews and writes a Thai work order
(Markdown + PDF via headless Chrome). Nothing in output_R3, MACHINING.md or the CAD inputs is modified.
2026-10-18: rebuilt after the wedgelet (1.6 mm, perpendicular) and upright edge-tap fixes; the package refuses a
build whose constraints do not carry both fixes.
Run from the repository: .venv-v4-print/bin/python robot_v4/print_revision/r3/RFQ/make_laser_rfq_package.py
"""
import hashlib
import html
import json
import math
import shutil
import subprocess
import zipfile
from pathlib import Path

import cadquery as cq
import ezdxf
import ezdxf.bbox
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import Frontend, RenderContext
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from ezdxf.addons.drawing.config import BackgroundPolicy, ColorPolicy, Configuration

HERE = Path(__file__).resolve().parent
R3 = HERE.parent
SRC = R3 / 'output_R3' / 'DRAFT' / 'metal'
REPORT = json.loads((R3 / 'output_R3' / 'build_report.json').read_text())
NAME = 'V4_R3_LASER_RFQ_ONLY_NOT_FOR_PRODUCTION'
OUT = HERE / NAME
DATE = '2026-10-18'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
STEEL, AL = 7.85e-3, 2.70e-3
BANNER = 'ขอราคาเท่านั้น — ห้ามผลิต (QUOTE REQUEST ONLY — NOT FOR PRODUCTION)'

INPUTS = json.loads((R3 / 'inputs_R3.json').read_text())['design']
WEDGE, EDGE = INPUTS['wedgelet'], INPUTS['upright_edge_tap']
C = REPORT['constraints']
if C.get('wedgelet_thickness_mm') != WEDGE['thickness_mm'] or 'upright_edge_tap_min_wall_mm' not in C:
    raise RuntimeError('build_report.json predates the wedgelet / edge-tap fix; rebuild output_R3 first')

PARTS = [
    dict(id='M01', file='Beater_Disc_L', name='จานอาวุธ (beater disc)', qty=2, material='เหล็ก 4140 (สภาพอบอ่อน) หรือ Hardox 450',
         t='6.0', density=STEEL, step_only=False,
         ops=['รู Ø3.4 ×4 เล็กกว่าความหนา: ให้เลเซอร์แค่มาร์กจุด แล้วเจาะด้วยดอกสว่าน',
              'countersink 90° ที่รู Ø3.4 ×4 ด้านเดียว (ด้านนอกของแต่ละจาน) สำหรับสกรู M3 หัวจม',
              '4140: เจาะและ countersink ให้เสร็จก่อนชุบแข็ง ถามร้านว่าชุบแข็งเองหรือส่งต่อ และทำได้ความแข็งเท่าไร',
              'Hardox 450: ถามว่าเจาะ/countersink หลังตัดได้หรือไม่ (วัสดุแข็งมาก)',
              'ลบคมทุกขอบ · การถ่วงสมดุลร่วมกับดุมทำทีหลัง ยังไม่อยู่ในใบนี้'],
         note='สองชิ้นเหมือนกันทุกประการ ใช้ไฟล์เดียว'),
    dict(id='M02', file='Upright_6061_6mm_L', name='แผ่นตั้งซ้าย (upright L)', qty=1, material='อลูมิเนียม 6061-T6', t='6.0', density=AL,
         ops=['รู Ø8.2 ×1 (แกน M8) ตัดเลเซอร์ได้',
              'รู Ø2.5 ×4 คือรูนำต๊าป: ให้เลเซอร์มาร์ก แล้วเจาะ Ø2.5 และต๊าป M3 ทะลุ (R3 แก้ใหม่: รูหลังสองรูย้ายไปห่างขอบหลัง 11 มม.)',
              'ต๊าป M3 ที่ขอบบน 1 รู และขอบล่าง 1 รู ห่างขอบหลัง 5 มม. กึ่งกลางความหนา: เจาะ Ø2.5 ลึก 8 (ปลายดอก 118°) ต๊าป M3 ลึก 6 มีใน STEP แต่ไม่อยู่ใน DXF',
              'ส่วนเว้าโค้งด้านหลังหลบมอเตอร์อาวุธมีเฉพาะชิ้นซ้าย', 'ลบคมทุกขอบ'],
         note='ใช้ไฟล์ซ้าย/ขวาแยกกัน ห้ามใช้แทนกัน'),
    dict(id='M03', file='Upright_6061_6mm_R', name='แผ่นตั้งขวา (upright R)', qty=1, material='อลูมิเนียม 6061-T6', t='6.0', density=AL,
         ops=['รู Ø8.2 ×1 ตัดเลเซอร์ได้', 'รู Ø2.5 ×4: มาร์ก → เจาะ Ø2.5 → ต๊าป M3 ทะลุ',
              'ต๊าป M3 ที่ขอบบน 1 รู และขอบล่าง 1 รู: เจาะ Ø2.5 ลึก 8 ต๊าป M3 ลึก 6 ตาม STEP (เหมือน M02)', 'ลบคมทุกขอบ'],
         note=''),
    dict(id='M04', file='Weapon_Top_Brace_3mm', name='คานยึดบน (top brace)', qty=1, material='อลูมิเนียม 6061-T6', t='3.0', density=AL,
         ops=['รู Ø3.4 ×4 และร่องหลบสายพานกว้าง 7 มม. ตรงกลาง ตัดเลเซอร์ได้', 'ลบคมทุกขอบ'],
         note='ไฟล์ของคานบนโดยเฉพาะ ห้ามใช้ไฟล์คานล่างแทน'),
    dict(id='M05', file='Weapon_Bottom_Brace_3mm', name='คานยึดล่าง (bottom brace)', qty=1, material='อลูมิเนียม 6061-T6', t='3.0', density=AL,
         ops=['รู Ø3.4 ×4 ตัดเลเซอร์ได้', 'ลบคมทุกขอบ'], note=''),
    dict(id='M06', file='Weapon_Motor_Mount_3mm', name='แผ่นยึดมอเตอร์อาวุธ', qty=1, material='อลูมิเนียม 6061-T6', t='3.0', density=AL,
         ops=['รู Ø10.5 ×1 และ Ø3.4 ×6 ตัดเลเซอร์ได้',
              'ตำแหน่งรูมอเตอร์ 4 รูและส่วนเว้าหลบมอเตอร์ขับหน้า ใช้ขนาดจากเว็บผู้ผลิต รอวัดมอเตอร์จริงก่อนผลิต',
              'ลบคมทุกขอบ'], note=''),
    dict(id='M07', file='Wedgelet_L', name='แผ่นลิ่ม (wedgelet) ซ้าย + ขวา', qty=2, material='เหล็กสปริง 65Mn หรือ SK5 (ขอราคา SPCC/SS400 เทียบด้วย)',
         t='%g' % WEDGE['thickness_mm'], density=STEEL, wedgelet=True,
         ops=['ตัดสองชิ้นจากไฟล์เดียว: ชิ้นซ้าย 1 ชิ้น ชิ้นขวา 1 ชิ้น',
              'countersink 90° Ø%g ที่รู Ø%g ×2 ด้านบน สำหรับสกรู M3 หัวเตเปอร์แฉก ISO 7046 / JIS B1111 (หัว ≤5.5 มม.) ต้องเหลือเนื้อใต้ countersink อย่างน้อย %g มม. ชิ้นซ้ายทำด้าน A ชิ้นขวาทำด้านตรงข้าม (เป็นชิ้นสะท้อนกัน ดู STEP ของชิ้นขวา)' % (WEDGE['countersink_diameter_mm'], WEDGE['hole_diameter_mm'], WEDGE['min_countersink_land_mm']),
              'เจียรขอบหน้าให้เอียง 35.5° จากแนวตั้งฉากกับผิวแผ่น ตามหน้าตัดใน STEP เพื่อให้ขอบหน้าตั้งตรงเมื่อประกอบ ขอบหลังตัดตรงตามเลเซอร์',
              'ถ้าเป็นเหล็กสปริง ถามว่าตัด/เจาะ/countersink ได้ในสภาพที่ซื้อมาหรือต้องอบอ่อนแล้วชุบใหม่',
              'ลบคมทุกขอบ ยกเว้นขอบหน้าที่เจียรคม'],
         note='STEP ของชิ้นขวาเป็นไฟล์ที่ทำจากการสะท้อนชิ้นซ้าย (DERIVED) ใช้ดูประกอบเท่านั้น'),
    dict(id='M08', file='Skirt_Plate_08mm_R', name='แผ่นกันข้าง (side skirt) ซ้าย + ขวา', qty=2, material='อลูมิเนียม 5052-H32', t='0.8', density=AL,
         ops=['รู Ø2.2 ×4 ตัดเลเซอร์ได้',
              'ขอราคาเพิ่ม: เปลี่ยนรูกลมเป็นร่องยาว 2.2 × 3.2 มม. ตามแนวกว้างของแผ่น (ปรับความสูงได้ราว 1 มม.)',
              'ลบคมทุกขอบ'],
         note='สองชิ้นใช้ไฟล์เดียว ไม่มีด้านหน้าหรือด้านหลัง STEP ของชิ้นซ้ายเป็นไฟล์ที่สะท้อนจากชิ้นขวา (DERIVED)'),
    dict(id='M09', file='Skirt_Plate_08mm_Rear', name='แผ่นกันท้าย (rear skirt)', qty=1, material='อลูมิเนียม 5052-H32', t='0.8', density=AL,
         ops=['รู Ø2.2 ×3 ตัดเลเซอร์ได้', 'ขอราคาเพิ่ม: ร่องยาว 2.2 × 3.2 มม. แบบเดียวกับ M08', 'ลบคมทุกขอบ'], note=''),
]
DERIVED = [('Wedgelet_L', 'Wedgelet_R'), ('Skirt_Plate_08mm_R', 'Skirt_Plate_08mm_L')]
TURNED_EXCLUDED = ['Beater_Hub_6061_D30.step', 'Motor_Pulley_D30_1to1.step', 'Spacer_Inner_ID8.2_OD11.step',
                   'Spacer_Outer_L_ID8.2_OD11.step', 'Spacer_Outer_R_ID8.2_OD11.step']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dxf_stats(path):
    msp = ezdxf.readfile(path).modelspace()
    length, holes = 0.0, {}
    for e in msp:
        kind = e.dxftype()
        if kind == 'LINE':
            length += math.dist(e.dxf.start, e.dxf.end)
        elif kind == 'CIRCLE':
            length += 2 * math.pi * e.dxf.radius
            d = round(2 * e.dxf.radius, 2)
            holes[d] = holes.get(d, 0) + 1
        elif kind == 'ARC':
            length += math.radians((e.dxf.end_angle - e.dxf.start_angle) % 360) * e.dxf.radius
    box = ezdxf.bbox.extents(msp)
    return dict(cut_mm=round(length), size=(round(box.size.x, 1), round(box.size.y, 1)),
                holes=dict(sorted(holes.items())), units=ezdxf.readfile(path).header.get('$INSUNITS'))


def plate_area(step_path):
    shape = cq.importers.importStep(str(step_path)).val()
    face = max((f for f in shape.Faces() if f.geomType() == 'PLANE'), key=lambda f: (len(f.Wires()), f.Area()))
    return shape, face.Area()


def preview(dxf_path, png_path, title):
    doc = ezdxf.readfile(dxf_path)
    box = ezdxf.bbox.extents(doc.modelspace())
    aspect = box.size.y / box.size.x
    width = 4.0 if aspect < 1.4 else max(1.6, 5.2 / aspect)
    fig = plt.figure(figsize=(width, min(5.2, width * aspect) + 0.5), dpi=170)
    ax = fig.add_axes([0.04, 0.03, 0.92, 0.82])
    config = Configuration(background_policy=BackgroundPolicy.WHITE, color_policy=ColorPolicy.BLACK, min_lineweight=0.35)
    Frontend(RenderContext(doc), MatplotlibBackend(ax), config=config).draw_layout(doc.modelspace(), finalize=True)
    fig.suptitle('%s\n%.1f x %.1f mm' % (title, box.size.x, box.size.y), fontsize=7, family='DejaVu Sans')
    fig.savefig(png_path, facecolor='white')
    plt.close(fig)


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    for sub in ('01_DXF_laser', '02_STEP_reference', '03_PREVIEW'):
        (OUT / sub).mkdir(parents=True)
    files = []
    centroids = {p['part']: p for p in REPORT['mass']['parts']}
    rows = []
    for part in PARTS:
        dxf_src, step_src = SRC / (part['file'] + '.dxf'), SRC / (part['file'] + '.step')
        dxf_dst, step_dst = OUT / '01_DXF_laser' / dxf_src.name, OUT / '02_STEP_reference' / step_src.name
        shutil.copy2(dxf_src, dxf_dst)
        shutil.copy2(step_src, step_dst)
        for src, dst in ((dxf_src, dxf_dst), (step_src, step_dst)):
            if sha(src) != sha(dst):
                raise RuntimeError('copy changed ' + src.name)
            files.append({'file': str(dst.relative_to(OUT)), 'source': str(src.relative_to(R3)), 'sha256': sha(dst), 'derived': False})
        stats = dxf_stats(dxf_src)
        if stats['units'] != 4:
            raise RuntimeError(dxf_src.name + ' DXF units are not millimetres')
        shape, area = plate_area(step_src)
        # Thickness = distance between the two largest flat faces (true perpendicular plate thickness).
        big = sorted((f for f in shape.Faces() if f.geomType() == 'PLANE'), key=lambda f: -f.Area())[:2]
        cad_t = big[0].distance(big[1])
        png = OUT / '03_PREVIEW' / (part['file'] + '.png')
        preview(dxf_src, png, part['id'] + ' ' + part['file'])
        files.append({'file': str(png.relative_to(OUT)), 'source': 'rendered from DXF', 'sha256': sha(png), 'derived': True})
        if part.get('wedgelet'):
            if abs(cad_t - WEDGE['thickness_mm']) > 1e-3:
                raise RuntimeError('wedgelet STEP is %.4f mm, inputs say %g' % (cad_t, WEDGE['thickness_mm']))
            mass = {WEDGE['thickness_mm']: centroids['Wedgelet_L']['mass_g']}
        else:
            mass = {float(part['t']): area * float(part['t']) * part['density']}
        rows.append(dict(part, **stats, area_mm2=round(area), cad_thickness_mm=round(cad_t, 3), mass_g=mass, png=png.name))
    # Mirror-derived reference STEPs; must reproduce the build's other-hand body.
    derived_checks = []
    for src_name, dst_name in DERIVED:
        shape = cq.importers.importStep(str(SRC / (src_name + '.step'))).val()
        mirrored = shape.mirror('YZ', (0, 0, 0))
        ref = centroids[dst_name]
        density = STEEL if src_name.startswith('Wedgelet') else AL
        centre = mirrored.Center().toTuple()
        error = max(abs(a - b) for a, b in zip(centre, ref['centroid_mm']))
        mass = mirrored.Volume() * density
        if error > 0.01 or abs(mass - ref['mass_g']) > 0.05:
            raise RuntimeError('%s mirror does not match build: centroid error %.4f, mass %.3f vs %.3f' % (dst_name, error, mass, ref['mass_g']))
        dst = OUT / '02_STEP_reference' / ('DERIVED_%s_mirror_of_%s.step' % (dst_name, src_name))
        mirrored.exportStep(str(dst))
        files.append({'file': str(dst.relative_to(OUT)), 'source': 'mirror of ' + src_name + '.step across x=0', 'sha256': sha(dst), 'derived': True})
        derived_checks.append({'part': dst_name, 'centroid_error_mm': round(error, 5), 'mass_g': round(mass, 4), 'build_report_mass_g': ref['mass_g']})
    write_documents(rows, files, derived_checks)


def balance_numbers():
    m = REPORT['mass']
    return dict(total=m['total_g'], rear=m['rear_static_load_fraction'], wedge=next(p['mass_g'] for p in m['parts'] if p['part'] == 'Wedgelet_L'),
                land=C['wedgelet_countersink_land_mm'], wall=C['upright_edge_tap_min_wall_mm'])


def write_documents(rows, files, derived_checks):
    bn = balance_numbers()
    pieces = sum(r['qty'] for r in rows)
    cut_total = sum(r['cut_mm'] * r['qty'] for r in rows)
    build_sha = REPORT['build_sha256']

    def holes(r):
        return ', '.join('Ø%g ×%d' % (d, n) for d, n in r['holes'].items())

    def mass_txt(r):
        return '%.1f g' % next(iter(r['mass_g'].values()))

    groups = {}
    for r in rows:
        key = (r['material'].split(' (')[0], r['t'])
        groups[key] = groups.get(key, 0) + r['qty']

    issues = [
        ('ขนาดจากมอเตอร์ที่ยังไม่ได้วัด (M02, M06)',
         'รูยึดมอเตอร์อาวุธ ส่วนเว้าหลบมอเตอร์ขับหน้าใน M06 และส่วนเว้าหลังของ M02 ใช้ขนาดจากเว็บผู้ผลิต ยังไม่ได้วัดตัวจริง', []),
        ('countersink แผ่นลิ่ม (M07)',
         'ขนาด countersink Ø%g ใน STEP คิดจากหัวสกรูสูงสุด 5.5 มม. ต้องวัดหัวสกรูที่ซื้อจริงก่อนทำ' % WEDGE['countersink_diameter_mm'],
         ['ถ้าหัวจริงใหญ่กว่า 5.5 มม. (เช่น DIN 7991 หัว 6.0) เนื้อใต้ countersink จะเหลือไม่ถึง %g มม. ห้ามขยาย countersink เอง ให้ถามผู้ออกแบบ' % WEDGE['min_countersink_land_mm']]),
    ]
    fixed = [
        'แผ่นลิ่มหนา %g มม. วัดตั้งฉากผิวแผ่นใน STEP แล้ว (R3 เดิมหนาจริงเพียง 1.63 มม. ไม่ใช่ 2 มม.) ชิ้นละ %.1f g หุ่นรวม %.1f g ล้อหลังรับ %.2f%% เนื้อใต้ countersink %.2f มม.' % (
            WEDGE['thickness_mm'], bn['wedge'], bn['total'], 100 * bn['rear'], bn['land']),
        'รูต๊าปขอบแผ่นตั้งอยู่ใน STEP แล้ว (เจาะ Ø%g ลึก %g ต๊าปลึก %g) และย้ายรูต๊าปด้านข้างจากห่างขอบหลัง 6 เป็น 11 มม. เหลือเนื้อกั้นระหว่างรูอย่างน้อย %.1f มม.' % (
            EDGE['drill_diameter_mm'], EDGE['drill_depth_mm'], EDGE['thread_depth_mm'], bn['wall']),
    ]

    questions = [
        'ร้านมีวัสดุตามตารางหรือไม่ ถ้าไม่มี เสนอเกรดใกล้เคียงพร้อมราคา (โดยเฉพาะ 4140/Hardox 6 มม., เหล็กสปริง 1.6 มม., 5052 0.8 มม.)',
        'รูที่เล็กกว่าความหนาแผ่น (Ø2.5 ใน 6 มม., Ø3.4 ใน 6 มม.) ร้านเจาะต่อให้ได้หรือไม่ คิดราคาเท่าไร',
        'ต๊าป M3: ทะลุ 8 รูในแผ่นตั้ง และที่ขอบ 4 รู (เจาะ Ø2.5 ลึก 8 ต๊าปลึก 6 กึ่งกลางความหนา 6 มม.) รับทำหรือไม่',
        'countersink 90°: จาน 8 รู แผ่นลิ่ม 4 รู รับทำหรือไม่',
        'ชุบแข็งจาน 4140 หลังเจาะ ทำเองหรือส่งต่อ ได้ความแข็งเท่าไร ราคาเท่าไร',
        'เจียรขอบหน้าแผ่นลิ่มเอียง 35.5° รับทำหรือไม่',
        'ร่องยาวแทนรูกลมที่แผ่นกันข้าง/ท้าย คิดเพิ่มเท่าไร',
        'ค่าความคลาดเคลื่อนของเลเซอร์และรูที่ร้านรับประกันได้ (รู Ø8.2 ของแกน M8 สำคัญที่สุด)',
        'ราคาแยกเป็น ค่าวัสดุ / ค่าตัด / งานเจาะ-ต๊าป-countersink / ชุบแข็ง / ลบคม / ขั้นต่ำ / VAT / ค่าส่ง / ระยะเวลา / อายุใบเสนอราคา',
    ]
    meta = [('Revision', 'Robot V4 Print R3 — DRAFT_NOT_RELEASED'), ('Build SHA256', build_sha), ('วันที่', DATE),
            ('หน่วย', 'มิลลิเมตร (DXF $INSUNITS = 4)'), ('จำนวน', '%d ชิ้น จาก %d ไฟล์ DXF · ระยะตัดรวมโดยประมาณ %d มม.' % (pieces, len(rows), cut_total))]

    # ---------- Markdown ----------
    md = ['# ใบขอราคาตัดเลเซอร์ — Robot V4 R3', '', '**' + BANNER + '**', '',
          'ใบนี้ใช้ขอราคาเท่านั้น ไม่ใช่ใบสั่งผลิต ยังไม่อนุมัติให้ตัดหรือซื้อวัสดุ เพราะยังมีขนาดที่รอวัดตามหัวข้อ "เรื่องที่ยังไม่ล็อก"', '']
    md += ['| | |', '|---|---|'] + ['| %s | %s |' % (k, v) for k, v in meta] + ['']
    md += ['## รายการชิ้นงาน', '', '| ID | ไฟล์ DXF | ชิ้นงาน | วัสดุ | หนา (มม.) | จำนวน | ขนาดแผ่น (มม.) | รู | ระยะตัด/ชิ้น | มวล/ชิ้น |', '|---|---|---|---|---|---:|---|---|---:|---|']
    for r in rows:
        md.append('| %s | `%s.dxf` | %s | %s | %s | %d | %.1f × %.1f | %s | %d มม. | %s |' % (
            r['id'], r['file'], r['name'], r['material'], r['t'], r['qty'], r['size'][0], r['size'][1], holes(r), r['cut_mm'], mass_txt(r)))
    md += ['', '### สรุปตามวัสดุ', ''] + ['- %s หนา %s มม.: %d ชิ้น' % (k[0], k[1], n) for k, n in groups.items()]
    md += ['', '## งานหลังตัดที่ต้องการให้ร้านเสนอราคา', '']
    for r in rows:
        md.append('**%s %s** ×%d' % (r['id'], r['name'], r['qty']) + (' — ' + r['note'] if r['note'] else ''))
        md += ['- ' + op for op in r['ops']] + ['']
    md += ['## แก้แบบแล้วใน build นี้', ''] + ['- ' + f for f in fixed] + ['']
    md += ['## เรื่องที่ยังไม่ล็อก (ต้องวัดหรือยืนยันก่อนผลิต)', '']
    for n, (title, text, bullets) in enumerate(issues, 1):
        md += ['%d. **%s** — %s' % (n, title, text)] + ['   - ' + b for b in bullets]
    md += ['', '## คำถามถึงร้าน', ''] + ['%d. %s' % (n, q) for n, q in enumerate(questions, 1)]
    md += ['', '## ไม่อยู่ในใบนี้', '',
           '- ชิ้นกลึง (ส่งร้านกลึง CNC ตาม MACHINING.md): ' + ', '.join(TURNED_EXCLUDED),
           '- สกรู น็อต insert แกนบานพับ และ E-clip ผู้ใช้ซื้อเอง',
           '- ไฟล์ STL ทั้งหมด (ใช้กับร้านพิมพ์ 3D เท่านั้น)',
           '', '## ไฟล์ในชุดนี้', '',
           '- `01_DXF_laser/` ไฟล์ตัด 2D ใช้ตัดจริง (คัดลอกจาก output_R3 โดยไม่แก้ไข)',
           '- `02_STEP_reference/` โมเดล 3D ใช้ดูประกอบ ไฟล์ที่ขึ้นต้นด้วย `DERIVED_` ได้จากการสะท้อนชิ้นอีกข้าง และตรวจกับ build แล้ว',
           '- `03_PREVIEW/` ภาพตัวอย่างจาก DXF', '- `SHA256SUMS.txt` และ `package_manifest.json` ใช้ยืนยันว่าไฟล์ตรงกับ build นี้', '',
           '> ' + BANNER]
    (OUT / 'WORK_ORDER_TH.md').write_text('\n'.join(md) + '\n')

    # ---------- HTML -> PDF ----------
    e = html.escape
    tr = ''.join('<tr><td>%s</td><td class="m">%s.dxf</td><td>%s</td><td>%s</td><td>%s</td><td class="n">%d</td><td class="m">%.1f × %.1f</td><td class="m">%s</td><td class="n">%d</td><td class="m">%s</td></tr>' % (
        r['id'], e(r['file']), e(r['name']), e(r['material']), e(r['t']), r['qty'], r['size'][0], r['size'][1], e(holes(r)), r['cut_mm'], e(mass_txt(r))) for r in rows)
    ops = ''.join('<div class="op"><h3>%s %s ×%d</h3>%s<ul>%s</ul></div>' % (
        r['id'], e(r['name']), r['qty'], ('<p class="note">%s</p>' % e(r['note']) if r['note'] else ''), ''.join('<li>%s</li>' % e(o) for o in r['ops'])) for r in rows)
    iss = ''.join('<li><b>%s</b> — %s%s</li>' % (e(t), e(x), ('<ul>%s</ul>' % ''.join('<li>%s</li>' % e(b) for b in bs) if bs else '')) for t, x, bs in issues)
    qs = ''.join('<li>%s</li>' % e(q) for q in questions)
    figs = ''.join('<figure><img src="03_PREVIEW/%s"><figcaption>%s · %s · หนา %s มม. · ×%d</figcaption></figure>' % (
        r['png'], r['id'], e(r['name']), e(r['t']), r['qty']) for r in rows)
    metatab = ''.join('<tr><th>%s</th><td class="m">%s</td></tr>' % (e(k), e(v)) for k, v in meta)
    doc = '''<!doctype html><html lang="th"><head><meta charset="utf-8"><title>V4 R3 Laser RFQ</title><style>
@page{size:A4;margin:12mm 12mm 12mm}
body{padding-bottom:8mm;font-family:"Sukhumvit Set","Thonburi",sans-serif;font-size:9.6pt;color:#111;line-height:1.5}
.banner{border:2px solid #b00;color:#b00;font-weight:700;padding:6px 10px;text-align:center;font-size:11pt;margin-bottom:8px}
.foot{position:fixed;bottom:0;left:0;right:0;background:#fff;border-top:1px solid #b00;padding-top:2px;text-align:center;color:#b00;font-size:8pt;font-weight:600}
h1{font-size:15pt;margin:0 0 4px}h2{font-size:11.5pt;margin:14px 0 6px;border-bottom:1px solid #999}h3{font-size:10pt;margin:6px 0 2px}
table{border-collapse:collapse;width:100%%}td,th{border:1px solid #bbb;padding:2px 4px;vertical-align:top;text-align:left}
th{background:#eee}.m{font-family:Menlo,monospace;font-size:8pt}.n{text-align:right}
.meta th{width:22%%}.op{break-inside:avoid}.op ul{margin:2px 0 6px 18px;padding:0}.note{margin:0;color:#444}
ol,ul{margin-top:2px}.issues>li{margin-bottom:6px}
.grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px}figure{margin:0;break-inside:avoid;border:1px solid #ccc;padding:3px}
figure img{max-width:100%%;max-height:62mm;display:block;margin:0 auto}figcaption{font-size:8pt}
</style></head><body>
<div class="foot">%(banner)s · build %(short)s</div>
<div class="banner">%(banner)s</div>
<h1>ใบขอราคาตัดเลเซอร์ — Robot V4 R3</h1>
<p>ใบนี้ใช้ขอราคาเท่านั้น ไม่ใช่ใบสั่งผลิต ยังไม่อนุมัติให้ตัดหรือซื้อวัสดุ เพราะยังมีขนาดที่รอวัด ดูหัวข้อ "เรื่องที่ยังไม่ล็อก"</p>
<table class="meta">%(meta)s</table>
<h2>รายการชิ้นงาน</h2>
<table><tr><th>ID</th><th>ไฟล์ DXF</th><th>ชิ้นงาน</th><th>วัสดุ</th><th>หนา มม.</th><th>จำนวน</th><th>ขนาด มม.</th><th>รู</th><th>ระยะตัด มม.</th><th>มวล/ชิ้น</th></tr>%(rows)s</table>
<h2>งานหลังตัดที่ต้องการให้ร้านเสนอราคา</h2>%(ops)s
<h2>แก้แบบแล้วใน build นี้</h2><ul>%(fixed)s</ul>
<h2>เรื่องที่ยังไม่ล็อก (ต้องวัดหรือยืนยันก่อนผลิต)</h2><ol class="issues">%(issues)s</ol>
<h2>คำถามถึงร้าน</h2><ol>%(qs)s</ol>
<h2>ไม่อยู่ในใบนี้</h2><ul><li>ชิ้นกลึง ส่งร้านกลึง CNC: %(turned)s</li><li>สกรู น็อต insert แกนบานพับ E-clip ผู้ใช้ซื้อเอง</li><li>ไฟล์ STL (ร้านพิมพ์ 3D เท่านั้น)</li></ul>
<h2>ภาพตัวอย่างจาก DXF (ใช้ไฟล์ DXF ในการตัด ห้ามวัดจากภาพ)</h2><div class="grid">%(figs)s</div>
</body></html>''' % dict(banner=e(BANNER), short=build_sha[:12], meta=metatab, rows=tr, ops=ops, issues=iss, fixed=''.join('<li>%s</li>' % e(f) for f in fixed), qs=qs, turned=e(', '.join(TURNED_EXCLUDED)), figs=figs)
    html_path = OUT / 'WORK_ORDER_TH.html'
    html_path.write_text(doc)
    pdf = OUT / 'WORK_ORDER_TH.pdf'
    subprocess.run([CHROME, '--headless=new', '--disable-gpu', '--no-pdf-header-footer', '--print-to-pdf=' + str(pdf), html_path.as_uri()],
                   check=True, capture_output=True, timeout=120)
    html_path.unlink()
    for name in ('WORK_ORDER_TH.md', 'WORK_ORDER_TH.pdf'):
        files.append({'file': name, 'source': 'generated', 'sha256': sha(OUT / name), 'derived': True})
    manifest = {'status': 'QUOTE_REQUEST_ONLY_NOT_FOR_PRODUCTION', 'revision': REPORT['revision'], 'build_sha256': build_sha,
                'r3_status': REPORT['status'], 'date': DATE, 'pieces': pieces, 'dxf_files': len(rows), 'cut_length_total_mm': cut_total,
                'parts': [{k: r[k] for k in ('id', 'file', 'name', 'material', 't', 'qty', 'size', 'holes', 'cut_mm', 'area_mm2', 'cad_thickness_mm')} |
                          {'mass_g_by_thickness': {str(t): round(m, 2) for t, m in r['mass_g'].items()}} for r in rows],
                'fixes_in_this_build': {'wedgelet': WEDGE, 'upright_edge_tap': EDGE, 'upright_side_screws_yz_mm': INPUTS['upright_side_screws_yz_mm'],
                                        'wedgelet_countersink_land_mm': round(bn['land'], 3), 'upright_edge_tap_min_wall_mm': round(bn['wall'], 3),
                                        'mass_total_g': bn['total'], 'rear_static_load_fraction': bn['rear']},
                'derived_mirror_checks': derived_checks, 'files': files}
    (OUT / 'package_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'SHA256SUMS.txt').write_text(''.join('%s  %s\n' % (f['sha256'], f['file']) for f in files))
    zip_path = HERE / (NAME + '.zip')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in sorted(OUT.rglob('*')):
            if path.is_file():
                z.write(path, Path(NAME) / path.relative_to(OUT))
    print(json.dumps({'package': str(OUT.relative_to(R3)), 'zip': str(zip_path.relative_to(R3)), 'pieces': pieces, 'cut_mm': cut_total,
                      'wedgelet_g': round(bn['wedge'], 2), 'rear_load_pct': round(100 * bn['rear'], 3), 'derived': derived_checks}, ensure_ascii=False, indent=1))


if __name__ == '__main__':
    main()
